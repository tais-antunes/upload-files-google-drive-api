import { Link } from 'react-router-dom';

function ProjetoDois() {
  return (
    <div>
      {/* Conteúdo da página ProjetoDois */}
      <Link to="/" className="button">Voltar</Link>
    </div>
  );
}

export default ProjetoDois;
