import { Link } from 'react-router-dom';

function ProjetoUm() {
  return (
    <div>
      {/* Conteúdo da página ProjetoUm */}
      <Link to="/" className="button">Voltar</Link>
    </div>
  );
}

export default ProjetoUm;
